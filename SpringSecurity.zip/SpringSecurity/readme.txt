1. The project need MySQL support

2. schema.sql in /etc should be import to MySQL before you run the project

3. If you want to run the project, please check the artical: http://www.javaeye.com/wiki/struts2/1321-struts2-development-environment-to-build

4. The JettyStarter is in /test/runtime